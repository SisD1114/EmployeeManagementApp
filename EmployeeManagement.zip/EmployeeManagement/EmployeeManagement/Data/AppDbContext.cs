﻿using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;



namespace EmployeeManagement.Data
{
    public class AppDbContext: DbContext
    {
        //the below creates an employee table inside our DB context
        public DbSet<Employee> Employees { get; set; }

        //add a constructor and pass the options created in our constructor to the base DbContext
        public AppDbContext(DbContextOptions<AppDbContext> options)
            :base(options)
        {
            
        }
    }
}
