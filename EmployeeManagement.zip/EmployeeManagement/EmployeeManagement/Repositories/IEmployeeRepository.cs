﻿using EmployeeManagement.Models;


namespace EmployeeManagement.Repositories
{
    public interface IEmployeeRepository
    {

        //make the request async 
        Task<IEnumerable<Employee>> GetAllAsync(); //read all
        Task <Employee?> GetByIdAsync(int id); //read one by id

        Task AddEmployeeAsync(Employee employee);

        Task UpdateEmployeeAsync(Employee employee);
        Task DeleteEmployeeAsync(int id);
    
    }
}
