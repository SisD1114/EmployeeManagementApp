export const environment = {
    isProduction: true,
    apirUrl: ''
}