export const environment = {
    isProduction: false,
    apirUrl: 'https://localhost:7121/api'
}