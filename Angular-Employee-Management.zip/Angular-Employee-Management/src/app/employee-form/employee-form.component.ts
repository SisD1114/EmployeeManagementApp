import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Employee } from '../../Models/employee';
import { EmployeeService } from '../employee.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent implements OnInit {

  employee: Employee = {
    id: 0,
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    position: ''
  }

  isEditing: boolean = false;

  //error property
  errorMessage:string = "";
  //dependency injection
    constructor(private employeeService: EmployeeService, 
      private router:Router,
      private activeRoute: ActivatedRoute
    ){}

  ngOnInit(): void {
    
    this.activeRoute.paramMap.subscribe((result) => {
    const id = result.get('id'); 

    if(id)
    {
      this.isEditing = true
      this.employeeService.getEmployeeById(Number(id)).subscribe({

        next: (result) => this.employee = result,
        error: (err) => this.errorMessage = `Error occured(${err.status})`
      })
      
    }
    
    });
  }

  onSubmit():void{

    //logic to edit an employee
    if(this.isEditing)
    {
              this.employeeService.editEmployee(this.employee)
          .subscribe({
            next: (response) => {
              this.router.navigate(['/']);
            },
            error:(err) =>{
              console.error(err);
              this.errorMessage = `Error occured during an updating(${err.status})`;
            }

        });
    }
    else //logic to add a new employee
    {
        this.employeeService.createEmployee(this.employee)
        .subscribe({
          next: (response) => {
            this.router.navigate(['/']);
          },
          error:(err) =>{
            console.error(err);
            this.errorMessage = `Error occured during creating(${err.status})`;
          }

        });
    }
    
     
  
  }

}
